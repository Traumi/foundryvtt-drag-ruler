# Drag Ruler Temporary fix
This project is a temporary fix for drag-ruler and is not the official mod

It may have some bugs but it should work at least for Foundry v10.285 to v10.286

You can find the original project here : https://github.com/manuelVo/foundryvtt-drag-ruler

When the official update will comes out it should theorically be automatically updated

# Installation

To install this module :

- Inside Foundry, select the Game Modules tab in the Configuration and Setup menu.
- Click the Install Module button and enter the following URL : `https://raw.githubusercontent.com/Traumi/foundryvtt-drag-ruler/master/module.json`
- Click Install and wait for installation to complete.

-OR-

- Download the archive in https://github.com/Traumi/foundryvtt-drag-ruler/releases/download/v1.12.13/drag-ruler-1.12.13.zip
- Replace the drag-ruler folder in FoundryData/Data/modules/drag-ruler by the one in the archive

# Changelog

1.12.13 (Stable)
- Token will follow the designated path and not taking shortcuts accros walls sometimes

1.12.12
- Minor improvements for less powerful computers

1.12.11
- Fixed a bug that were preventing waypoints to work on gridless maps

1.12.10
- Fixed the pathfinding part

# Known Bug

- No one for now :)
